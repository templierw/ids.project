package overlay.frames;

import java.io.Serializable;

public abstract class Sendable implements Serializable {
    
}
