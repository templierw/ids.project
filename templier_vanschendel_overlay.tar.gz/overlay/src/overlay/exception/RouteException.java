package overlay.exception;

public class RouteException extends Exception {

    private static final long serialVersionUID = 1L;

    public RouteException(String msg) {
        super(msg);
    }
    
}
